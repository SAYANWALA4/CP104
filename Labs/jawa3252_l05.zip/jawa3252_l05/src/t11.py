"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-10-09"
-------------------------------------------------------
"""
# Imports
from functions import quadrant

result = quadrant(0, -3)

print (result)
