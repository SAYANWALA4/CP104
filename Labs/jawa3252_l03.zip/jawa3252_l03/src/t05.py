"""
-------------------------------------------------------
Lab 3, task 5
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-09-23"
-------------------------------------------------------
"""

mini = int(input("Enter minimum: "))
maxi = int(input("Enter maxixmum: "))
diff = maxi - mini

print(f"The difference betweeen {maxi: d} and {mini: d} is {diff: d}")
