"""
-------------------------------------------------------
Lab 3, task 15
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-09-25"
-------------------------------------------------------
"""

integer = 654321
decimal = 654.32
phrase = "Hello World"

print(f"{integer:d}")
print(f"{integer:f}")
# print(f"{integer:s}") # can't convert int to string

# print(f"{decimal:d}") # cant convert float to int
print(f"{decimal:f}")
# print(f"{decimal:s}") # cant convert float to string

# print(f"{phrase:d}") # cant convert string to int
# print(f"{phrase:f}") # cant convert string to decimal
print(f"{phrase:s}")
