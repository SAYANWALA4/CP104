"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-10-21"
-------------------------------------------------------
"""
# Imports
from functions import draw_triangle

draw_triangle(6, "*")
