"""
-------------------------------------------------------
Task 1, Lab 07
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-10-29"
-------------------------------------------------------
"""
# Imports
from functions import hi_lo_game
# Constants

count = hi_lo_game(100)

print(f"You made {count} guesses.")

