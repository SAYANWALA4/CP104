"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-10-30"
-------------------------------------------------------
"""
# Imports
from functions import budget

expenses, balance, status = budget(200)

print(expenses, balance, status)
