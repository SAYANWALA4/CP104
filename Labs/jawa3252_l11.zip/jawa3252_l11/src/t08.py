"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-11-29"
-------------------------------------------------------
"""
# Imports
from functions import find_less
# Constants

print(find_less([[8, 2, -3], [7, 4, 4], [-2, -1, 0], [-1, -6, 2]], 8))
