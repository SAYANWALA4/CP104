"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-11-29"
-------------------------------------------------------
"""
# Imports
from functions import matrix_stats
# Constants

print(matrix_stats([[2, 0, -1, 1], [10, 4, -5, 9], [-6, 3, 6, 0]]))
