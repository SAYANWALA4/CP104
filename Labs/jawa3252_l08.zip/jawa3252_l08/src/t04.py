"""
-------------------------------------------------------
Lab 8, task 4
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-11-07"
-------------------------------------------------------
"""
# Imports
from functions import generate_integer_list
# Constants

print(generate_integer_list(10, -100, 100))
