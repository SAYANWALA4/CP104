"""
-------------------------------------------------------
Lab 8, task 7
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-11-08"
-------------------------------------------------------
"""
# Imports
from functions import list_categorize

print(list_categorize([94, 96, -22, -79, -28, -26, -50, 71, 24, -32]))
