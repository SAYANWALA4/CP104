"""
-------------------------------------------------------
Lab 8, task 15
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-11-08"
-------------------------------------------------------
"""
# Imports
from functions import symmetric_difference

print(symmetric_difference([10, 3, 10, 3, 1], [8, 2, 7, 3, 6, 10, 32, 99]))
