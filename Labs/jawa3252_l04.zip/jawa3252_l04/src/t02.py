"""
-------------------------------------------------------
Task 2, Lab 4
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-10-04"
-------------------------------------------------------
"""
# Imports
from functions import circumference
# Constants

circ = circumference(2.5)

print(f"{circ: .2f}")

circ = circumference(5)

print(f"{circ: .2f}")

circ = circumference(0.5)

print(f"{circ: .2f}")

