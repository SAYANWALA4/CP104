"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-10-06"
-------------------------------------------------------
"""
from functions import extract_date

date = 20241212

print(f"extract_date({date}) -> {extract_date(date)}")

date = 19621025

print(f"extract_date({date}) -> {extract_date(date)}")

date = 20231212

print(f"extract_date({date}) -> {extract_date(date)}")
