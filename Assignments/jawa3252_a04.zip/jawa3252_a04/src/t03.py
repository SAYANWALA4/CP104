"""
-------------------------------------------------------
Assignment 4, Task 3
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-10-12"
-------------------------------------------------------
"""
# Imports
from functions import largest_average

print(largest_average(10, 12, 14))

print(largest_average(-8, 36, 42))

print(largest_average(-1, -2, -4))

print(largest_average(512, 2242, 14151))
