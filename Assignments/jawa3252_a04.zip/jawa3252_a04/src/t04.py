"""
-------------------------------------------------------
Assignment 4, Task 4
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-10-12"
-------------------------------------------------------
"""
from functions import colour_combine

RED = "red"
GREEN = "green"
BLUE = "blue"

print(colour_combine(RED, GREEN))

print(colour_combine(BLUE, GREEN))

print(colour_combine(RED, RED))

print(colour_combine("purple", GREEN))
