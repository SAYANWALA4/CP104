"""
-------------------------------------------------------
Assignment 4, Task 5
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-10-12"
-------------------------------------------------------
"""
from functions import hoo_rah

print(hoo_rah(42))

print(hoo_rah(21))

print(hoo_rah(20))

print(hoo_rah(3))
