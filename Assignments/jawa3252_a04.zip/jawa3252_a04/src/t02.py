"""
-------------------------------------------------------
Assignment 4, Task 2
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-10-12"
-------------------------------------------------------
"""
# Imports
from functions import pollution_ranking

print(pollution_ranking(-10))

print(pollution_ranking(170))

print(pollution_ranking(220))

print(pollution_ranking(20))
