"""
-------------------------------------------------------
Assignment 4, Task 1
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-10-12"
-------------------------------------------------------
"""
# Imports
from functions import day_name

print(day_name(2))

print(day_name(4))

print(day_name(7))

print(day_name(12))
