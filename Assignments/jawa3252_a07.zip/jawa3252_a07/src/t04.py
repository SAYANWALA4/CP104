"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-11-10"
-------------------------------------------------------
"""
from functions import list_subtract

minuend1 = [2, 7, 6, 21, 442, 36, 2]

minuend2 = [2, 7, 6, 21, 442, 36, 2]

minuend3 = [2, 7, 6, 21, 442, 36, 2]

list_subtract(minuend1, [2])

list_subtract(minuend2, [7])

list_subtract(minuend3, [0])

print(minuend1)
print(minuend2)
print(minuend3)
