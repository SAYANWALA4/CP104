"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-11-10"
-------------------------------------------------------
"""
from functions import list_factors

print(list_factors(9))

print(list_factors(999))

print(list_factors(13))
