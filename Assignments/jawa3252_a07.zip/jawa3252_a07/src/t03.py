"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-11-10"
-------------------------------------------------------
"""
from functions import get_indexes

indexes = get_indexes([-2, 5, 7, 2, 9, 0, 2, 4, 6], 2)
print(indexes)
