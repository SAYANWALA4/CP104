"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-10-30"
-------------------------------------------------------
"""
from functions import count_of_digits

print(count_of_digits(25))

print(count_of_digits(0))

print(count_of_digits(2423498237423))
