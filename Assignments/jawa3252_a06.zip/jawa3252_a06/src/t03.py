"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-10-30"
-------------------------------------------------------
"""
# Imports

# Constants
from functions import interest_table

interest_table(750, 5, 200)

interest_table(0, 0, 10)

interest_table(500, 25, 20)
