"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-10-30"
-------------------------------------------------------
"""
# Imports
from functions import factor_summation

print(factor_summation(25))

print(factor_summation(36))

print(factor_summation(224))
