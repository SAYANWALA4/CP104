"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-10-27"
-------------------------------------------------------
"""
from functions import calc_factorial

print(calc_factorial(0))

print(calc_factorial(-8))

print(calc_factorial(10))
