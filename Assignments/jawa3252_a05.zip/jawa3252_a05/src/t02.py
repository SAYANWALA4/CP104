"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-10-27"
-------------------------------------------------------
"""
from functions import calories_treadmill

calories_treadmill(0, 100)

print(" ")

calories_treadmill(8, 5)

print(" ")

calories_treadmill(1, 20)
