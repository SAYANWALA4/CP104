"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-10-27"
-------------------------------------------------------
"""
from functions import range_addition

print(range_addition(1, 4, 37))

print(range_addition(1, 24, 312))

print(range_addition(1, 7, 0))
