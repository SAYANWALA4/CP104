"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jaspreet Jawanda
ID:      169083252
Email:   jawa3252@mylaurier.ca
__updated__ = "2024-09-17"
-------------------------------------------------------
"""

# User inputs their age and favourite band and its outputed as a introduction to the user
user_age = int(input("What is your age? "))
user_band = str(input("What is your favourite band? "))

print(f"I am {user_age} years old and {user_band} is my favourite band.")
